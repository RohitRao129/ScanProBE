import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { NewFileComponent } from './new-file/new-file.component';
import { RepoHomeComponent } from './repo-home/repo-home.component';
import { RepoManageComponent } from './repo-manage/repo-manage.component';
import { ShowImgComponent } from './show-img/show-img.component';

const routes: Routes = [
  { path: '', component: HomePageComponent },
  { path:"repo/:path",component: RepoHomeComponent},
  { path:"manageRepo/:name",component: RepoManageComponent},
  { path:"addDirectory/:path/:type",component: NewFileComponent},
  { path:"showImg/:path/:name",component: ShowImgComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
