package com.mavericks.scanpro.authentcation;

import com.mavericks.scanpro.entities.User;
import com.mavericks.scanpro.repositories.UserRepo;
import com.mavericks.scanpro.requests.SignUpRequest;
import com.mavericks.scanpro.response.AuthResponseDTO;
import com.mavericks.scanpro.services.EmailServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class SignUpController {

    private static final Logger LOGGER = LoggerFactory.getLogger(SignUpController.class);

    @Autowired
    private UserRepo userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private EmailServiceImpl emailService;
    @PostMapping("/signup")
    @ResponseBody
    public ResponseEntity<AuthResponseDTO> signUp(@RequestBody SignUpRequest signUpRequest) {
        AuthResponseDTO res = new AuthResponseDTO();

        if(userRepository.findByEmail(signUpRequest.getEmail())!=null){
            res.setSuccess(false);
            res.setMessage("Already registered!");

            return  new ResponseEntity<AuthResponseDTO>(res,HttpStatus.OK);
        }

        User user = new User();
        user.setFullname(signUpRequest.getFullname());
        user.setEmail(signUpRequest.getEmail().toLowerCase());
        user.setEmailVerified(false);
        user.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));
        user.setRole("USER");
        userRepository.save(user);

        try {
            emailService.sendVerificationEmail(signUpRequest.getEmail());
        }catch (Exception e){
            LOGGER.error("email sender Failed :",e);

            res.setSuccess(false);
            res.setMessage("Unable to send Email!");
            userRepository.delete(user);
            return new ResponseEntity<AuthResponseDTO>(res,HttpStatus.OK);
        }
        res.setSuccess(true);
        res.setMessage("User Registred Successfully!");
        return new ResponseEntity<AuthResponseDTO>(res,HttpStatus.OK);
    }
}