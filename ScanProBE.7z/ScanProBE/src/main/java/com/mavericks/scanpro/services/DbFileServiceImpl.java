package com.mavericks.scanpro.services;

import com.mavericks.scanpro.entities.Github_files;
import com.mavericks.scanpro.repositories.GithubFileRepo;
import com.mavericks.scanpro.response.SearchFileResDTO;
import com.mavericks.scanpro.services.interfaces.DbFileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.querydsl.QPageRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;


@Service
public class DbFileServiceImpl implements DbFileService {
    @Autowired
    private GithubFileRepo githubFileRepo;

    public ArrayList<Github_files> SearchFileByName(String Name, Long PageNumber,Integer Limit){
        Long offset = (PageNumber-1)*Limit;
        return githubFileRepo.findAllByNameWithPageLimit(Name,Limit,offset);
    }


    public HashMap<String,String> ScanDoc(String B64String){
        HashMap<String,String> mp =new HashMap<>();
        mp.put("invoice_number","2345678");
        mp.put("subtotal","2345678");
        mp.put("tax","2345678");
        mp.put("total_amount","2345678");
        mp.put("date",new Date().toString());
        mp.put("address","kuks321i");
        mp.put("phone","8451564207");
        mp.put("name","Rohit2");
        return mp;
    }
}
