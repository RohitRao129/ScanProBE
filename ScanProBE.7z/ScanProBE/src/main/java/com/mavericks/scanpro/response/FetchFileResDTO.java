package com.mavericks.scanpro.response;

import lombok.Getter;
import lombok.Setter;

@Setter@Getter
public class FetchFileResDTO {
    private String Name;

    private String Sha;

    private String content;

}
