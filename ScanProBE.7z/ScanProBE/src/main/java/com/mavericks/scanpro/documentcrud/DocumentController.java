package com.mavericks.scanpro.documentcrud;

import com.mavericks.scanpro.repositories.UserRepo;
import com.mavericks.scanpro.requests.FetchFileReqDTO;
import com.mavericks.scanpro.requests.UpdateFileReqDTO;
import com.mavericks.scanpro.requests.UploadFileReqDTO;
import com.mavericks.scanpro.response.FetchFileResDTO;
import com.mavericks.scanpro.response.SaveFileResDTO;
import com.mavericks.scanpro.security.jwt.JwtUtils;
import com.mavericks.scanpro.services.GithubFileServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/docs")
public class DocumentController {
    Logger log = LoggerFactory.getLogger(DocumentController.class);

    @Autowired
    private GithubFileServiceImpl git_Service;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private UserRepo userRepo;

    @PostMapping("/fetchOrg")
    @ResponseBody
    private ResponseEntity<?> fetchOriginalDoc(@RequestBody FetchFileReqDTO req){
        FetchFileResDTO response =git_Service.FetchFromGithub(req.getPath());
        if(response==null){
            return new ResponseEntity<>("Not Found!", HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(value = "/uploadOrg",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseBody
    private ResponseEntity<?> uploadOrgDoc(@ModelAttribute UploadFileReqDTO req,@RequestHeader("Authorization") String headers ){
        Long id=0L;
        if (headers != null && headers.startsWith("Bearer ")) {
            String jwtToken = headers.substring(7);
            id = userRepo.findByEmail(jwtUtils.getUserNameFromJwtToken(jwtToken)).getId();
        }
        SaveFileResDTO response = git_Service.UploadOriginalDoc(id,req.getName(), req.getPath(), req.getFile());
        if(response==null){
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(value = "/updateOrg",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseBody
    private ResponseEntity<?> updateOrgDoc(@ModelAttribute UpdateFileReqDTO req, @RequestHeader("Authorization") String headers ){
        Long id=0L;
        if (headers != null && headers.startsWith("Bearer ")) {
            String jwtToken = headers.substring(7);
            id = userRepo.findByEmail(jwtUtils.getUserNameFromJwtToken(jwtToken)).getId();
        }
        SaveFileResDTO response = git_Service.UpdateOriginalDoc(id,req.getName(), req.getPath(),req.getSha(), req.getFile());
        if(response==null){
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
