package com.mavericks.scanpro.repositories;

import com.mavericks.scanpro.entities.ResetTokens;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResetTokenRepo extends JpaRepository<ResetTokens,Long> {
    ResetTokens findByResetToken(String token);
}
