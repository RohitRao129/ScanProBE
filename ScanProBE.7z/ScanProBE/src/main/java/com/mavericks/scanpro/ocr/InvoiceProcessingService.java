package com.mavericks.scanpro.ocr;

import com.azure.ai.formrecognizer.documentanalysis.models.*;
import com.azure.ai.formrecognizer.documentanalysis.DocumentAnalysisClient;
import com.azure.ai.formrecognizer.documentanalysis.DocumentAnalysisClientBuilder;
import com.azure.core.credential.AzureKeyCredential;
import com.azure.core.util.polling.SyncPoller;
import com.azure.core.util.BinaryData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;

@Service
public class InvoiceProcessingService {

    private static final Logger LOGGER = LoggerFactory.getLogger(InvoiceProcessingService.class);
    
    @Value("${azure.ocr.endpoint}")
    private String endpoint;

    @Value("${azure.ocr.subscription.key}")
    private String key;

    public String extractTextFromDocument(byte[] document) {
        try {
            DocumentAnalysisClient client = new DocumentAnalysisClientBuilder()
                    .credential(new AzureKeyCredential(key))
                    .endpoint(endpoint)
                    .buildClient();

            SyncPoller<OperationResult, AnalyzeResult> analyzeDocumentPoller = client.beginAnalyzeDocument(
                    "prebuilt-invoice",
                    BinaryData.fromBytes(document)
            );

            HashMap<String,String> res =new HashMap<>();

            AnalyzeResult analyzeResult = analyzeDocumentPoller.getFinalResult();
            StringBuilder extractedText = new StringBuilder();
            for (AnalyzedDocument analyzedDocument : analyzeResult.getDocuments()) {
                Map<String, DocumentField> fields = analyzedDocument.getFields();
                for (Map.Entry<String, DocumentField> entry : fields.entrySet()) {
                    String fieldName = entry.getKey();
                    DocumentField documentField = entry.getValue();
                    Object fieldValue = documentField.getValue();

                    if (fieldValue instanceof String) {
                        extractedText.append(fieldName).append(": ").append(fieldValue).append("\n");
                    } else {
                        LOGGER.warn("Field '{}' is not of type String. Value: {}", fieldName, fieldValue);
                    }
                }
            }

            System.out.println(res);
            //System.out.println(extractedText.toString());

            return extractedText.toString();

        } catch (Exception e) {
            LOGGER.error("Error occurred while extracting text from the document: {}", e.getMessage());
            return "Error occurred while extracting text from the document: " + e.getMessage();
        }
    }
}