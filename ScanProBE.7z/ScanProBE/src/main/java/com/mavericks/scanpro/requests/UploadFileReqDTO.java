package com.mavericks.scanpro.requests;

import lombok.Getter;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
public class UploadFileReqDTO {
    private String name;
    private MultipartFile file;
    private String path;
}
