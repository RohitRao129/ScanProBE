package com.mavericks.scanpro.controllers;

import com.mavericks.scanpro.entities.User;
import com.mavericks.scanpro.repositories.UserRepo;
import com.mavericks.scanpro.security.jwt.JwtUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/check")
public class CheckController {
    static final Logger LOGGER = LoggerFactory.getLogger(CheckController.class);
    @Autowired
    UserRepo userRepo;

    @Autowired
    JwtUtils jwtUtils;

    @GetMapping("/email")
    public Boolean IsEmailRegistred(@Param("email")String email){
        return userRepo.existsByEmail(email);
    }

    @GetMapping("/get/user")
    public User getUserById(@Param("id")Long id){
        return userRepo.findById(id).get();
    }

    @GetMapping("/validateJWT")
    public Boolean IsJwtValidate(@RequestHeader("Authorization") String headers ){
        Long id=0L;
        try{
            if (headers != null && headers.startsWith("Bearer ")) {
                String jwtToken = headers.substring(7);
                return jwtUtils.validateJwtToken(jwtToken);
            }
            return false;
        }catch (Exception e){
            LOGGER.error("Unable to get id from JWT token!",e);
            return false;
        }
    }

}
