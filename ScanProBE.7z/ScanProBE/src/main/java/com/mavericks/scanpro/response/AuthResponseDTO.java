package com.mavericks.scanpro.response;

import lombok.Setter;

@Setter
public class AuthResponseDTO {
    private Boolean success;
    private String message;
    private String token;
}
