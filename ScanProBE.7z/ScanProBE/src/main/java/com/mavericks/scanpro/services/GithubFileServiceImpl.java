package com.mavericks.scanpro.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mavericks.scanpro.documentcrud.DocumentController;
import com.mavericks.scanpro.entities.Github_files;
import com.mavericks.scanpro.repositories.GithubFileRepo;
import com.mavericks.scanpro.response.FetchFileResDTO;
import com.mavericks.scanpro.response.FileExplorerResDTO;
import com.mavericks.scanpro.response.SaveFileResDTO;
import com.mavericks.scanpro.services.interfaces.GithubFileService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;

@Service
public class GithubFileServiceImpl implements GithubFileService {
    Logger log = LoggerFactory.getLogger(DocumentController.class);
    @Autowired
    RestTemplate restTemplate;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    GithubFileRepo githubFileRepo;

    @Value("${Github.auth.code}")
    private String auth_Code;

    @Value("${Github.url}")
    private String git_url;

    private boolean AlreadyPresent(String path){
        if(githubFileRepo.findByPath(path)!=null)return true;
        return false;
    }

    public FileExplorerResDTO FileExplorerGithub(String path) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/vnd.github+json");
        headers.set("Authorization", "Bearer " + auth_Code);
        headers.set("X-GitHub-Api-Version", "2022-11-28");
        JsonNode res = null;

        try {
            ResponseEntity<String> response = restTemplate.getForEntity(git_url+path, String.class);
            res = objectMapper.readTree(response.getBody());
            log.info("Fetch response :{}", res);

        } catch (Exception e) {
            log.error("Some Error Occured :{}", e.toString());
            return null;
        }
        FileExplorerResDTO response = new FileExplorerResDTO();
        ArrayList<HashMap<String,String>> arr =new ArrayList<>();
        for(int i =0;i<res.size();i++){
            HashMap<String,String> mp =new HashMap<>();
            mp.put("name",res.get(i).get("name").asText() );
            mp.put("path",res.get(i).get("path").asText());
            mp.put("sha",res.get(i).get("sha").asText());
            mp.put("type",res.get(i).get("type").asText());
            mp.put("size",res.get(i).get("size").asText());

            arr.add(i,mp);
        }
        response.setFiles(arr);
        return response;
    }

    public FetchFileResDTO FetchFromGithub(String path) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/vnd.github+json");
        headers.set("Authorization", "Bearer " + auth_Code);
        headers.set("X-GitHub-Api-Version", "2022-11-28");
        JsonNode res = null;

        try {
            ResponseEntity<String> response = restTemplate.getForEntity(git_url+path, String.class);
            res = objectMapper.readTree(response.getBody());
            log.info("Fetch response :{}", res);

        } catch (Exception e) {
            log.error("Some Error Occured :{}", e.toString());
            return null;
        }

        FetchFileResDTO response = new FetchFileResDTO();
        response.setName(res.get("name").asText());
        response.setSha(res.get("sha").asText());
        response.setContent(res.get("content").asText());

        log.info("Reponsse from API :{}", response.getName());

        return response;
    }

    public SaveFileResDTO UploadOriginalDoc(Long id, String name, String path, MultipartFile file) {
        name =name.toUpperCase();
        SaveFileResDTO response =new SaveFileResDTO();
        String absolute_path =id.toString()+path+ name;

        if(AlreadyPresent(absolute_path)){
            response.setSuccess(false);
            response.setMessage("Duplicate");
            return response;
        }

        String url = git_url+absolute_path;
        JsonNode res = null;
        HttpStatus status;

        try{
            byte[] bytes = file.getBytes();
            String base64String = Base64.getEncoder().encodeToString(bytes);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Accept", "application/vnd.github+json");
            headers.set("Authorization", "Bearer " + auth_Code);
            headers.set("X-GitHub-Api-Version", "2022-11-28");

            String requestBody =String.format("{\"message\":\"random message\",\"content\":\"%s\"}",base64String);

            RestTemplate restTemplate = new RestTemplate();
            HttpEntity<String> requestEntity = new HttpEntity<>(requestBody, headers);
            ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, String.class);

            res = objectMapper.readTree(responseEntity.getBody());
            status = (HttpStatus) responseEntity.getStatusCode();

            log.info("response: {} ",res);

        }catch (JsonProcessingException e){
            log.error("Response parse error : {}",e);
            return null;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        if(status== HttpStatus.CREATED){
            Github_files Git_file = new Github_files();
            Git_file.setName(name);
            Git_file.setSha(res.get("content").get("sha").asText());
            Git_file.setPath(absolute_path);
            Git_file.setLast_update(new Date(System.currentTimeMillis()));
            Git_file.setSize(res.get("content").get("size").asLong());
            githubFileRepo.save(Git_file);
            System.out.println(res);
            response.setSuccess(true);
            response.setMessage("Saved!");
            response.setName(res.get("content").get("name").asText());
            response.setSha(res.get("content").get("sha").asText());
            response.setPath(res.get("content").get("path").asText());
        }
        else{
            response.setSuccess(false);
            response.setMessage("Some Error Occured");
        }

        return response;
    }

    public SaveFileResDTO UpdateOriginalDoc(Long id,String name, String path, String sha, MultipartFile file) {
        name =name.toUpperCase();
        SaveFileResDTO response =new SaveFileResDTO();
        String absolute_path =id.toString()+path+ name;

        if(!AlreadyPresent(absolute_path)){
            response.setSuccess(false);
            response.setMessage("Update Invalid");
            return response;
        }

        String url = git_url+absolute_path;
        JsonNode res = null;
        HttpStatus status;

        try{
            byte[] bytes = file.getBytes();
            String base64String = Base64.getEncoder().encodeToString(bytes);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Accept", "application/vnd.github+json");
            headers.set("Authorization", "Bearer " + auth_Code);
            headers.set("X-GitHub-Api-Version", "2022-11-28");

            String requestBody =String.format("{\"message\":\"random message\",\"sha\":\"%s\",  \"content\":\"%s\"}",sha,base64String);

            RestTemplate restTemplate = new RestTemplate();
            HttpEntity<String> requestEntity = new HttpEntity<>(requestBody, headers);
            ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, String.class);

            res = objectMapper.readTree(responseEntity.getBody());
            status = (HttpStatus) responseEntity.getStatusCode();

            log.info("response: {} ",res);

        }catch (JsonProcessingException e){
            log.error("Response parse error : {}",e);
            return null;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        if(status== HttpStatus.OK){

            Github_files Git_file = githubFileRepo.findByPath(absolute_path);
            Git_file.setName(name);
            Git_file.setSha(res.get("content").get("sha").asText());
            Git_file.setPath(absolute_path);
            Git_file.setSize(res.get("content").get("size").asLong());
            Git_file.setLast_update(new Date(System.currentTimeMillis()));
            githubFileRepo.save(Git_file);

            //System.out.println(res);

            response.setSuccess(true);
            response.setMessage("Updated!");
            response.setName(res.get("content").get("name").asText());
            response.setSha(res.get("content").get("sha").asText());
            response.setPath(res.get("content").get("path").asText());
        }
        else{
            response.setSuccess(false);
            response.setMessage("Some Error Occured");
        }

        return response;
    }


}