package com.mavericks.scanpro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScanproApplicationTests {

	@Test
	void contextLoads() {
	}

}
